
function Welcome() {
    return (
        <div class="container m-5">
            <section class="my-5 ">
                <h3 class="text-center row">April 5th, 2022</h3>
                <p class="text-center row">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                    laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                    culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </section>
            <section class="my-5">
                <h3 class="text-center row">February 28th, 2022</h3>
                <p class="text-center row">
                    Arcu dui vivamus arcu felis. At imperdiet dui accumsan sit amet nulla facilisi
                    morbi tempus. Id diam maecenas ultricies mi eget. Vulputate dignissim suspendisse in est ante in nibh
                    mauris cursus. Magnis dis parturient montes nascetur ridiculus mus. Vel fringilla est ullamcorper eget
                    nulla facilisi. Vitae semper quis lectus nulla. Nisi lacus sed viverra tellus. In hac habitasse platea
                    dictumst quisque sagittis.
                </p>
            </section>
            <section class="my-5">
                <h3 class="text-center row">January 25th, 2022</h3>
                <p class="text-center row">
                    Eu feugiat pretium nibh ipsum consequat nisl. Elit at imperdiet dui accumsan sit. Et magnis dis parturient
                    montes nascetur. Suspendisse interdum consectetur libero id faucibus nisl. Elit sed vulputate mi sit amet
                    mauris. Adipiscing bibendum est ultricies integer quis auctor. Diam vulputate ut pharetra sit amet.
                    Massa vitae tortor condimentum lacinia quis. Tortor posuere ac ut consequat.
                </p>
            </section>
        </div>
    );
}

export default Welcome;